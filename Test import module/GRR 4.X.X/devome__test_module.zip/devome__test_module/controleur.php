<?php

if($identifiant_hook == "hookHeader1"){
	
	$CtnHook['hookHeader1'] .= "Test Module !";
}

?>