<?php

if($identifiant_hook == "hookHeader1"){
	
	echo "Test Module !";
}

?>