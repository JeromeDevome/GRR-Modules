<?php

$module_nom = "Test module";
$module_description = "Permet de tester l'import et l'activation de module.";
$module_version = "1.0.0";
$module_versionBDD = 1; // A incrémenté a chaque modification de BDD
$module_autheur = "JeromeB - DEVOME";
$module_copyright = "<a href='https://boutique.devome.com/'>Licence GPL</a>";

$module_repertoire = "devome__test_module"; // Nom de dossier = Autheur + __ + nom du module ( un espace = _ ), que des caractere alphanumiric sans accent
$module_ref = "devome__test_module"; // Unique ne doit pas changer pendant la durer de vie du module, la valeur est égal au nom de dossier à la premiere version du module

$module_version_grr_mini = "3.3.2";
$module_version_grr_max = "3.4.0";




?>